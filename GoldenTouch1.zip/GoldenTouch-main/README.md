# GoldenTouch

## 📖 Description
A web application that allows users to browse and purchase smart accessories for iPads and other devices.

## 🛠️ Technologies Used
- React
- Node.js
- Express
- MongoDB

## 🚀 Setup Instructions
1. Clone the repository:
   ```bash
   git clone https://github.com/mariembahri45/GoldenTouch.git
