export const  products  =[
    {
    id: 100,
    name: "Perl Necklace",
    description: "A pendant necklace made from a slice of recycled circuit board, silver plated bail and chain. Geek chic and eco-friendly.",
    price: 35,
    qte: 0,
    rating: 4,
    image: "images/necklaces/necklace1.webp"
  },

  {
    id: 101,
    name: "Kaia Necklace",
    description: "The perfect throw-on-and-go piece. Dangling pearls with a hint of shine will have you feeling fresh and styled. Wear it with an open neckline or layer it with a delicate pendant for a layered look. We love it with a linen button-down, breezy dress, or lightweight knit",
    price: 22,
    qte: 0,
    rating: 4,
    image: "images/necklaces/necklace2.jpg"
  },
  {
    id: 102,
    name: "Mini Chloe ",
    description: "Crafted with a timeless silhouette of crystals that are sure to go with anything, you’ll never want to take this bracelet off. Let this bracelet shine on its own or pair with other bracelets to create a layered look.",
    price: 18,
    qte: 0,
    brand: "RetroTech Jewelry",
    rating: 3,
    image: "images/bracelets/bracelet1.webp"
  },
  {
    id: 103,
    name: "Basque Cuff",
    description: "An engraved metal cuff bracelet with binary code for ‘01001000’ (H) — subtle geek message.",
    price: 45,
    qte: 0,
    brand: "CodeWear",
    rating: 5,
    image: "images/bracelets/bracelet2.webp"
  },
  {
    id: 104,
    name: "Kaya Ring",
    description: "With the perfect balance of pearl and shine, this classic silhouette is an essential staple. You'll love catching glimpses of it on your finger. Comes packaged in a ready-to-gift box.",
    price: 28,
    qte: 0,
    brand: "Bytes & Pieces",
    rating: 4,
    image: "images/rings/ring1.webp"
  },
  {
    id: 105,
    name: "Jodie Ring",
    description: "Strikingly beautiful and unique, the Jodie ring features organic textures and luxurious touches. Adorned with hints of pave, it embodies a natural elegance only freshwater pearls can bring. ",
    price: 52,
    qte: 0,
    brand: "TechHeart Jewelry",
    rating: 4,
    image: "images/rings/ring2.webp"
  },
  {
    id: 106,
    name: "Serena Drops",
    description: "Like droplets of morning dew, these earrings bring a fresh, luminous feel to our signature clustered design. With pear-cut gems and cascading pearls, their organic silhouette moves beautifully with you.",
    price: 60,
    qte: 0,
    brand: "ElectroGlow",
    rating: 4,
    image: "images/earrings/1.webp"
  },
  {
    id: 107,
    name: "Carina Hoops",
    description: "Pearls, shimmer, and shine - these earrings have it all! Simple yet layered in luxe, these hoops offer the perfect final touch to an everyday outfit. Wear them with your hair tied back for a classic, sophisticated look.",
    price: 24,
    qte: 0,
    brand: "KeyCraft Jewelry",
    rating: 3,
    image: "images/earrings/2.webp"
  },
   {
    id: 106,
    name: "Serena Drops",
    description: "Like droplets of morning dew, these earrings bring a fresh, luminous feel to our signature clustered design. With pear-cut gems and cascading pearls, their organic silhouette moves beautifully with you.",
    price: 60,
    qte: 0,
    brand: "ElectroGlow",
    rating: 4,
    image: "images/earrings/1.webp"
  },
  {
    id: 107,
    name: "Carina Hoops",
    description: "Pearls, shimmer, and shine - these earrings have it all! Simple yet layered in luxe, these hoops offer the perfect final touch to an everyday outfit. Wear them with your hair tied back for a classic, sophisticated look.",
    price: 24,
    qte: 0,
    brand: "KeyCraft Jewelry",
    rating: 3,
    image: "images/earrings/2.webp"
  },
   {
    id: 106,
    name: "Serena Drops",
    description: "Like droplets of morning dew, these earrings bring a fresh, luminous feel to our signature clustered design. With pear-cut gems and cascading pearls, their organic silhouette moves beautifully with you.",
    price: 60,
    qte: 0,
    brand: "ElectroGlow",
    rating: 4,
    image: "images/earrings/1.webp"
  },
  {
    id: 107,
    name: "Carina Hoops",
    description: "Pearls, shimmer, and shine - these earrings have it all! Simple yet layered in luxe, these hoops offer the perfect final touch to an everyday outfit. Wear them with your hair tied back for a classic, sophisticated look.",
    price: 24,
    qte: 0,
    brand: "KeyCraft Jewelry",
    rating: 3,
    image: "images/earrings/2.webp"
  },
   {
    id: 106,
    name: "Serena Drops",
    description: "Like droplets of morning dew, these earrings bring a fresh, luminous feel to our signature clustered design. With pear-cut gems and cascading pearls, their organic silhouette moves beautifully with you.",
    price: 60,
    qte: 0,
    brand: "ElectroGlow",
    rating: 4,
    image: "images/earrings/1.webp"
  },
  {
    id: 107,
    name: "Carina Hoops",
    description: "Pearls, shimmer, and shine - these earrings have it all! Simple yet layered in luxe, these hoops offer the perfect final touch to an everyday outfit. Wear them with your hair tied back for a classic, sophisticated look.",
    price: 24,
    qte: 0,
    brand: "KeyCraft Jewelry",
    rating: 3,
    image: "images/earrings/2.webp"
  },
   {
    id: 106,
    name: "Serena Drops",
    description: "Like droplets of morning dew, these earrings bring a fresh, luminous feel to our signature clustered design. With pear-cut gems and cascading pearls, their organic silhouette moves beautifully with you.",
    price: 60,
    qte: 0,
    brand: "ElectroGlow",
    rating: 4,
    image: "images/earrings/1.webp"
  },
  {
    id: 107,
    name: "Carina Hoops",
    description: "Pearls, shimmer, and shine - these earrings have it all! Simple yet layered in luxe, these hoops offer the perfect final touch to an everyday outfit. Wear them with your hair tied back for a classic, sophisticated look.",
    price: 24,
    qte: 0,
    brand: "KeyCraft Jewelry",
    rating: 3,
    image: "images/earrings/2.webp"
  },
   {
    id: 106,
    name: "Serena Drops",
    description: "Like droplets of morning dew, these earrings bring a fresh, luminous feel to our signature clustered design. With pear-cut gems and cascading pearls, their organic silhouette moves beautifully with you.",
    price: 60,
    qte: 0,
    brand: "ElectroGlow",
    rating: 4,
    image: "images/earrings/1.webp"
  },
  {
    id: 107,
    name: "Carina Hoops",
    description: "Pearls, shimmer, and shine - these earrings have it all! Simple yet layered in luxe, these hoops offer the perfect final touch to an everyday outfit. Wear them with your hair tied back for a classic, sophisticated look.",
    price: 24,
    qte: 0,
    brand: "KeyCraft Jewelry",
    rating: 3,
    image: "images/earrings/2.webp"
  }
  
]


